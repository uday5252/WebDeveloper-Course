
const PlayButton = document.getElementById("play")

const MyVideo = document.querySelector("video")

let isVideoPlaying = false

function playVideo()
{
    MyVideo.play()

    PlayButton.classList.replace("fa-play", "fa-pause")
    
    isVideoPlaying = true
}

function pauseVideo()
{
    MyVideo.pause()

    PlayButton.classList.replace("fa-pause", "fa-play")

    isVideoPlaying = false
}

PlayButton.addEventListener("click", function()
{
    console.log("Hi")
    // Logic to play the video or pause the video
    if(isVideoPlaying)
    {
        pauseVideo()
    }
    else
    {
        playVideo()
    }
})

const CurrentTime = document.querySelector("#currenttime")

const Duration = document.querySelector("#duration")

const ProgressBar = document.querySelector(".progressbar")


MyVideo.addEventListener("timeupdate", function(event)
{
    let myCurrentTime =event.srcElement.currentTime
    let myDuration = event.srcElement.duration

    let currentTimeInMinutes = Math.floor(myCurrentTime / 60)
    let currentTimeInSeconds = Math.floor(myCurrentTime % 60)

    if(currentTimeInSeconds < 10)
    {
        currentTimeInSeconds = `0${currentTimeInSeconds}`
    }

    CurrentTime.textContent = `${currentTimeInMinutes}:${currentTimeInSeconds}/`

    let DurationInMinutes = Math.floor(myDuration / 60)
    let DurationInSeconds = Math.floor(myDuration % 60)

    if(DurationInSeconds < 10)
    {
        DurationInSeconds = `0${DurationInSeconds}`
    }

    

   let videoPlayedPercentage =  (myCurrentTime / myDuration) * 100 // 50
   console.log(videoPlayedPercentage)

   ProgressBar.style.width = `${videoPlayedPercentage}%`


    Duration.textContent = `${DurationInMinutes}:${DurationInSeconds}`



    
})

const ForwardButton = document.querySelector("#forwardbutton") 

ForwardButton.addEventListener("click", function()
{
    // Logic to fast forward the video by 5 sec

    MyVideo.currentTime = MyVideo.currentTime + 5
    
})


const VolumeContainer = document.querySelector(".volumecontainer")
const VolumeBar = document.querySelector(".volumebar")

VolumeContainer.addEventListener("click", function(event)
{
    // Two Details:-
    // Total width of the black color bar(VolumeContainer) --> 102
    // Total width from the starting of the back color bar till where the click is performed

    const totalWidth = event.srcElement.offsetWidth
    let totalWidthFromStart = event.offsetX

    let totalDistanceCoveredInPercentage = (totalWidthFromStart / totalWidth) * 100
    

    VolumeBar.style.width = `${totalDistanceCoveredInPercentage}%`

    // Total Apples = 10
    // Total Width = 102

    // Total Apples Consumed = 5
    // Total width covered = 50

    // Total percentage of the apples consumed = 5/10 * 100 = 50%
    // Total percentage of the width covered = 50/102 * 100 = 49%

    // volume --> 0 t0, 0(No Volume), 1(Full Volume), 0.5
    
   let volumeInfo = totalWidthFromStart / totalWidth
//    totalDistanceCoveredWithoutPercentage(0 to 1)


    MyVideo.volume = volumeInfo
})

const VolumeIcon = document.querySelector("#volumeicon")

let isVideoMuted = false

function muteVideo()
{
    isVideoMuted = true
    VolumeIcon.classList.replace("fa-volume-high", "fa-volume-mute")
    MyVideo.volume = 0.0
    VolumeBar.style.width = `${0}%`

}

function unMuteVideo()
{
    isVideoMuted = false
    VolumeIcon.classList.replace("fa-volume-mute", "fa-volume-high")
    MyVideo.volume = 1.0
    VolumeBar.style.width = `${100}%`
}

VolumeIcon.addEventListener("click", function()
{
    // Change it to mute icon and give the video volume = 0

    if(isVideoMuted)
    {
        unMuteVideo()
    }
    else
    {
        muteVideo()
    }
})



const DropDown = document.querySelector("#speed")
DropDown.addEventListener("change", function(event)
{
    MyVideo.playbackRate = event.target.value
})

const ExpandScreen = document.querySelector("#expand")
const MainDiv = document.querySelector(".main")



ExpandScreen.addEventListener("click", function()
{
    MyVideo.classList.add("fullScreen")
    // if it is not in full screen mode, it returns null
    
    // if(document.fullscreenElement == null)
    // is not
    if(!document.fullscreenElement)
    {
        // Then we need to make it to full screen
        if(MainDiv.requestFullscreen)
        {
            MainDiv.requestFullscreen()
        }
    }
    else
    {
        console.log(document.fullscreenElement)
        MyVideo.classList.add("exitScreen")
        document.exitFullscreen()
    }
})


